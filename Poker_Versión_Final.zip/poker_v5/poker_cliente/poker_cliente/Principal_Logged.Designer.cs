﻿namespace poker_cliente
{
    partial class Principal_Logged
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal_Logged));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.logOut = new System.Windows.Forms.ToolStripSplitButton();
            this.dataGridConectados = new System.Windows.Forms.DataGridView();
            this.CrearPartida = new System.Windows.Forms.Panel();
            this.DGVInvitados = new System.Windows.Forms.DataGridView();
            this.Invitado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Accepted = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.EnviarPartida = new System.Windows.Forms.Button();
            this.LabelInvitado3 = new System.Windows.Forms.Label();
            this.LabelInvitado2 = new System.Windows.Forms.Label();
            this.LabelInvitado1 = new System.Windows.Forms.Label();
            this.SelecctionarLablel = new System.Windows.Forms.Label();
            this.LabelMode = new System.Windows.Forms.Label();
            this.Titulo_invitar = new System.Windows.Forms.Label();
            this.Jugador3ComboBox = new System.Windows.Forms.ComboBox();
            this.Jugador2ComboBox = new System.Windows.Forms.ComboBox();
            this.Jugador1ComboBox = new System.Windows.Forms.ComboBox();
            this.ModeComboBox = new System.Windows.Forms.ComboBox();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridConectados)).BeginInit();
            this.CrearPartida.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVInvitados)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOut});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1274, 27);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // logOut
            // 
            this.logOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.logOut.Image = ((System.Drawing.Image)(resources.GetObject("logOut.Image")));
            this.logOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.logOut.Name = "logOut";
            this.logOut.Size = new System.Drawing.Size(81, 24);
            this.logOut.Text = "Log Out";
            this.logOut.ToolTipText = "Log out";
            this.logOut.Click += new System.EventHandler(this.logOut_Click);
            // 
            // dataGridConectados
            // 
            this.dataGridConectados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridConectados.Location = new System.Drawing.Point(24, 375);
            this.dataGridConectados.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridConectados.Name = "dataGridConectados";
            this.dataGridConectados.RowHeadersWidth = 62;
            this.dataGridConectados.RowTemplate.Height = 28;
            this.dataGridConectados.Size = new System.Drawing.Size(316, 268);
            this.dataGridConectados.TabIndex = 2;
            this.dataGridConectados.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridConectados_CellContentClick);
            // 
            // CrearPartida
            // 
            this.CrearPartida.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.CrearPartida.AutoSize = true;
            this.CrearPartida.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.CrearPartida.Controls.Add(this.DGVInvitados);
            this.CrearPartida.Controls.Add(this.EnviarPartida);
            this.CrearPartida.Controls.Add(this.LabelInvitado3);
            this.CrearPartida.Controls.Add(this.LabelInvitado2);
            this.CrearPartida.Controls.Add(this.LabelInvitado1);
            this.CrearPartida.Controls.Add(this.SelecctionarLablel);
            this.CrearPartida.Controls.Add(this.LabelMode);
            this.CrearPartida.Controls.Add(this.Titulo_invitar);
            this.CrearPartida.Controls.Add(this.Jugador3ComboBox);
            this.CrearPartida.Controls.Add(this.Jugador2ComboBox);
            this.CrearPartida.Controls.Add(this.Jugador1ComboBox);
            this.CrearPartida.Controls.Add(this.ModeComboBox);
            this.CrearPartida.Location = new System.Drawing.Point(380, 76);
            this.CrearPartida.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CrearPartida.Name = "CrearPartida";
            this.CrearPartida.Size = new System.Drawing.Size(751, 441);
            this.CrearPartida.TabIndex = 5;
            this.CrearPartida.Paint += new System.Windows.Forms.PaintEventHandler(this.CrearPartida_Paint_1);
            // 
            // DGVInvitados
            // 
            this.DGVInvitados.AllowUserToAddRows = false;
            this.DGVInvitados.AllowUserToDeleteRows = false;
            this.DGVInvitados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DGVInvitados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVInvitados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVInvitados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Invitado,
            this.Accepted});
            this.DGVInvitados.Location = new System.Drawing.Point(360, 186);
            this.DGVInvitados.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DGVInvitados.Name = "DGVInvitados";
            this.DGVInvitados.ReadOnly = true;
            this.DGVInvitados.RowHeadersWidth = 51;
            this.DGVInvitados.RowTemplate.Height = 24;
            this.DGVInvitados.Size = new System.Drawing.Size(344, 206);
            this.DGVInvitados.TabIndex = 6;
            // 
            // Invitado
            // 
            this.Invitado.HeaderText = "Invitado";
            this.Invitado.MinimumWidth = 6;
            this.Invitado.Name = "Invitado";
            this.Invitado.ReadOnly = true;
            // 
            // Accepted
            // 
            this.Accepted.HeaderText = "Accepted?";
            this.Accepted.MinimumWidth = 6;
            this.Accepted.Name = "Accepted";
            this.Accepted.ReadOnly = true;
            this.Accepted.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Accepted.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // EnviarPartida
            // 
            this.EnviarPartida.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.EnviarPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnviarPartida.Location = new System.Drawing.Point(426, 81);
            this.EnviarPartida.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EnviarPartida.Name = "EnviarPartida";
            this.EnviarPartida.Size = new System.Drawing.Size(204, 76);
            this.EnviarPartida.TabIndex = 5;
            this.EnviarPartida.Text = "Invitar";
            this.EnviarPartida.UseVisualStyleBackColor = true;
            this.EnviarPartida.Click += new System.EventHandler(this.EnviarPartida_Click_1);
            // 
            // LabelInvitado3
            // 
            this.LabelInvitado3.AutoSize = true;
            this.LabelInvitado3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelInvitado3.Location = new System.Drawing.Point(40, 299);
            this.LabelInvitado3.Name = "LabelInvitado3";
            this.LabelInvitado3.Size = new System.Drawing.Size(96, 25);
            this.LabelInvitado3.TabIndex = 4;
            this.LabelInvitado3.Text = "Invitado 3";
            this.LabelInvitado3.Visible = false;
            // 
            // LabelInvitado2
            // 
            this.LabelInvitado2.AutoSize = true;
            this.LabelInvitado2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelInvitado2.Location = new System.Drawing.Point(40, 234);
            this.LabelInvitado2.Name = "LabelInvitado2";
            this.LabelInvitado2.Size = new System.Drawing.Size(96, 25);
            this.LabelInvitado2.TabIndex = 4;
            this.LabelInvitado2.Text = "Invitado 2";
            this.LabelInvitado2.Visible = false;
            // 
            // LabelInvitado1
            // 
            this.LabelInvitado1.AutoSize = true;
            this.LabelInvitado1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelInvitado1.Location = new System.Drawing.Point(40, 171);
            this.LabelInvitado1.Name = "LabelInvitado1";
            this.LabelInvitado1.Size = new System.Drawing.Size(96, 25);
            this.LabelInvitado1.TabIndex = 4;
            this.LabelInvitado1.Text = "Invitado 1";
            this.LabelInvitado1.Visible = false;
            // 
            // SelecctionarLablel
            // 
            this.SelecctionarLablel.AutoSize = true;
            this.SelecctionarLablel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelecctionarLablel.Location = new System.Drawing.Point(40, 137);
            this.SelecctionarLablel.Name = "SelecctionarLablel";
            this.SelecctionarLablel.Size = new System.Drawing.Size(221, 25);
            this.SelecctionarLablel.TabIndex = 4;
            this.SelecctionarLablel.Text = "Selecciona los invitados";
            // 
            // LabelMode
            // 
            this.LabelMode.AutoSize = true;
            this.LabelMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelMode.Location = new System.Drawing.Point(40, 74);
            this.LabelMode.Name = "LabelMode";
            this.LabelMode.Size = new System.Drawing.Size(343, 25);
            this.LabelMode.TabIndex = 4;
            this.LabelMode.Text = "Selecciona cuantos jugadores quieres";
            // 
            // Titulo_invitar
            // 
            this.Titulo_invitar.AutoSize = true;
            this.Titulo_invitar.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titulo_invitar.Location = new System.Drawing.Point(37, 27);
            this.Titulo_invitar.Name = "Titulo_invitar";
            this.Titulo_invitar.Size = new System.Drawing.Size(269, 46);
            this.Titulo_invitar.TabIndex = 3;
            this.Titulo_invitar.Text = "Crear Partida";
            // 
            // Jugador3ComboBox
            // 
            this.Jugador3ComboBox.FormattingEnabled = true;
            this.Jugador3ComboBox.Items.AddRange(new object[] {
            "2",
            "4"});
            this.Jugador3ComboBox.Location = new System.Drawing.Point(44, 330);
            this.Jugador3ComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Jugador3ComboBox.Name = "Jugador3ComboBox";
            this.Jugador3ComboBox.Size = new System.Drawing.Size(182, 24);
            this.Jugador3ComboBox.TabIndex = 0;
            this.Jugador3ComboBox.Visible = false;
            // 
            // Jugador2ComboBox
            // 
            this.Jugador2ComboBox.FormattingEnabled = true;
            this.Jugador2ComboBox.Items.AddRange(new object[] {
            "2",
            "4"});
            this.Jugador2ComboBox.Location = new System.Drawing.Point(44, 264);
            this.Jugador2ComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Jugador2ComboBox.Name = "Jugador2ComboBox";
            this.Jugador2ComboBox.Size = new System.Drawing.Size(182, 24);
            this.Jugador2ComboBox.TabIndex = 0;
            this.Jugador2ComboBox.Visible = false;
            // 
            // Jugador1ComboBox
            // 
            this.Jugador1ComboBox.FormattingEnabled = true;
            this.Jugador1ComboBox.Items.AddRange(new object[] {
            "2",
            "4"});
            this.Jugador1ComboBox.Location = new System.Drawing.Point(44, 202);
            this.Jugador1ComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Jugador1ComboBox.Name = "Jugador1ComboBox";
            this.Jugador1ComboBox.Size = new System.Drawing.Size(182, 24);
            this.Jugador1ComboBox.TabIndex = 0;
            this.Jugador1ComboBox.Visible = false;
            // 
            // ModeComboBox
            // 
            this.ModeComboBox.FormattingEnabled = true;
            this.ModeComboBox.Items.AddRange(new object[] {
            "2",
            "4"});
            this.ModeComboBox.Location = new System.Drawing.Point(44, 104);
            this.ModeComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ModeComboBox.Name = "ModeComboBox";
            this.ModeComboBox.Size = new System.Drawing.Size(182, 24);
            this.ModeComboBox.TabIndex = 0;
            this.ModeComboBox.SelectedIndexChanged += new System.EventHandler(this.ModeComboBox_SelectedIndexChanged);
            // 
            // Principal_Logged
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1274, 715);
            this.Controls.Add(this.CrearPartida);
            this.Controls.Add(this.dataGridConectados);
            this.Controls.Add(this.toolStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Principal_Logged";
            this.Text = "Principal_Logged";
            this.Load += new System.EventHandler(this.Principal_Logged_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridConectados)).EndInit();
            this.CrearPartida.ResumeLayout(false);
            this.CrearPartida.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVInvitados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton logOut;
        private System.Windows.Forms.DataGridView dataGridConectados;
        private System.Windows.Forms.Panel CrearPartida;
        private System.Windows.Forms.DataGridView DGVInvitados;
        private System.Windows.Forms.DataGridViewTextBoxColumn Invitado;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Accepted;
        private System.Windows.Forms.Button EnviarPartida;
        private System.Windows.Forms.Label LabelInvitado3;
        private System.Windows.Forms.Label LabelInvitado2;
        private System.Windows.Forms.Label LabelInvitado1;
        private System.Windows.Forms.Label SelecctionarLablel;
        private System.Windows.Forms.Label LabelMode;
        private System.Windows.Forms.Label Titulo_invitar;
        private System.Windows.Forms.ComboBox Jugador3ComboBox;
        private System.Windows.Forms.ComboBox Jugador2ComboBox;
        private System.Windows.Forms.ComboBox Jugador1ComboBox;
        private System.Windows.Forms.ComboBox ModeComboBox;
    }
}