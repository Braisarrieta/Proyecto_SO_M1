﻿namespace poker_cliente
{
    partial class Interfaz_juego
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_chat = new System.Windows.Forms.Panel();
            this.Chatlabel = new System.Windows.Forms.Label();
            this.ChatEnviar = new System.Windows.Forms.Button();
            this.ChatOutput = new System.Windows.Forms.TextBox();
            this.ChatInput = new System.Windows.Forms.TextBox();
            this.Mano1 = new System.Windows.Forms.Panel();
            this.Mano2 = new System.Windows.Forms.Panel();
            this.Mano3 = new System.Windows.Forms.Panel();
            this.Mano4 = new System.Windows.Forms.Panel();
            this.Mano5 = new System.Windows.Forms.Panel();
            this.baraja1 = new System.Windows.Forms.Panel();
            this.baraja2 = new System.Windows.Forms.Panel();
            this.baraja3 = new System.Windows.Forms.Panel();
            this.Pasar_Btn = new System.Windows.Forms.Button();
            this.baraja4 = new System.Windows.Forms.Panel();
            this.baraja5 = new System.Windows.Forms.Panel();
            this.panel_chat.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_chat
            // 
            this.panel_chat.Controls.Add(this.Chatlabel);
            this.panel_chat.Controls.Add(this.ChatEnviar);
            this.panel_chat.Controls.Add(this.ChatOutput);
            this.panel_chat.Controls.Add(this.ChatInput);
            this.panel_chat.Location = new System.Drawing.Point(12, 10);
            this.panel_chat.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panel_chat.Name = "panel_chat";
            this.panel_chat.Size = new System.Drawing.Size(399, 389);
            this.panel_chat.TabIndex = 2;
            // 
            // Chatlabel
            // 
            this.Chatlabel.AutoSize = true;
            this.Chatlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chatlabel.Location = new System.Drawing.Point(32, 16);
            this.Chatlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Chatlabel.Name = "Chatlabel";
            this.Chatlabel.Size = new System.Drawing.Size(68, 29);
            this.Chatlabel.TabIndex = 3;
            this.Chatlabel.Text = "Chat ";
            // 
            // ChatEnviar
            // 
            this.ChatEnviar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ChatEnviar.Location = new System.Drawing.Point(275, 344);
            this.ChatEnviar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ChatEnviar.Name = "ChatEnviar";
            this.ChatEnviar.Size = new System.Drawing.Size(94, 31);
            this.ChatEnviar.TabIndex = 2;
            this.ChatEnviar.Text = "Enviar";
            this.ChatEnviar.UseVisualStyleBackColor = true;
            this.ChatEnviar.Click += new System.EventHandler(this.ChatEnviar_Click_1);
            // 
            // ChatOutput
            // 
            this.ChatOutput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ChatOutput.Enabled = false;
            this.ChatOutput.Location = new System.Drawing.Point(37, 48);
            this.ChatOutput.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ChatOutput.Multiline = true;
            this.ChatOutput.Name = "ChatOutput";
            this.ChatOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.ChatOutput.Size = new System.Drawing.Size(332, 289);
            this.ChatOutput.TabIndex = 1;
            // 
            // ChatInput
            // 
            this.ChatInput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ChatInput.Location = new System.Drawing.Point(35, 344);
            this.ChatInput.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ChatInput.Name = "ChatInput";
            this.ChatInput.Size = new System.Drawing.Size(231, 22);
            this.ChatInput.TabIndex = 0;
            // 
            // Mano1
            // 
            this.Mano1.BackColor = System.Drawing.Color.Transparent;
            this.Mano1.Location = new System.Drawing.Point(32, 586);
            this.Mano1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Mano1.Name = "Mano1";
            this.Mano1.Size = new System.Drawing.Size(175, 240);
            this.Mano1.TabIndex = 3;
            // 
            // Mano2
            // 
            this.Mano2.BackColor = System.Drawing.Color.Transparent;
            this.Mano2.Location = new System.Drawing.Point(241, 586);
            this.Mano2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Mano2.Name = "Mano2";
            this.Mano2.Size = new System.Drawing.Size(175, 240);
            this.Mano2.TabIndex = 4;
            // 
            // Mano3
            // 
            this.Mano3.BackColor = System.Drawing.Color.Transparent;
            this.Mano3.Location = new System.Drawing.Point(462, 586);
            this.Mano3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Mano3.Name = "Mano3";
            this.Mano3.Size = new System.Drawing.Size(175, 240);
            this.Mano3.TabIndex = 4;
            // 
            // Mano4
            // 
            this.Mano4.BackColor = System.Drawing.Color.Transparent;
            this.Mano4.Location = new System.Drawing.Point(668, 586);
            this.Mano4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Mano4.Name = "Mano4";
            this.Mano4.Size = new System.Drawing.Size(175, 240);
            this.Mano4.TabIndex = 4;
            this.Mano4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // Mano5
            // 
            this.Mano5.BackColor = System.Drawing.Color.Transparent;
            this.Mano5.Location = new System.Drawing.Point(876, 586);
            this.Mano5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Mano5.Name = "Mano5";
            this.Mano5.Size = new System.Drawing.Size(175, 240);
            this.Mano5.TabIndex = 4;
            // 
            // baraja1
            // 
            this.baraja1.BackColor = System.Drawing.Color.Transparent;
            this.baraja1.Location = new System.Drawing.Point(428, 106);
            this.baraja1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.baraja1.Name = "baraja1";
            this.baraja1.Size = new System.Drawing.Size(175, 240);
            this.baraja1.TabIndex = 5;
            // 
            // baraja2
            // 
            this.baraja2.BackColor = System.Drawing.Color.Transparent;
            this.baraja2.Location = new System.Drawing.Point(628, 106);
            this.baraja2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.baraja2.Name = "baraja2";
            this.baraja2.Size = new System.Drawing.Size(175, 240);
            this.baraja2.TabIndex = 5;
            // 
            // baraja3
            // 
            this.baraja3.BackColor = System.Drawing.Color.Transparent;
            this.baraja3.Location = new System.Drawing.Point(821, 106);
            this.baraja3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.baraja3.Name = "baraja3";
            this.baraja3.Size = new System.Drawing.Size(175, 240);
            this.baraja3.TabIndex = 5;
            // 
            // Pasar_Btn
            // 
            this.Pasar_Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pasar_Btn.Location = new System.Drawing.Point(1131, 684);
            this.Pasar_Btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Pasar_Btn.Name = "Pasar_Btn";
            this.Pasar_Btn.Size = new System.Drawing.Size(230, 74);
            this.Pasar_Btn.TabIndex = 7;
            this.Pasar_Btn.Text = "Salir";
            this.Pasar_Btn.UseVisualStyleBackColor = true;
            this.Pasar_Btn.Click += new System.EventHandler(this.Pasar_Btn_Click);
            // 
            // baraja4
            // 
            this.baraja4.BackColor = System.Drawing.Color.Transparent;
            this.baraja4.Location = new System.Drawing.Point(1020, 106);
            this.baraja4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.baraja4.Name = "baraja4";
            this.baraja4.Size = new System.Drawing.Size(175, 240);
            this.baraja4.TabIndex = 6;
            // 
            // baraja5
            // 
            this.baraja5.BackColor = System.Drawing.Color.Transparent;
            this.baraja5.Location = new System.Drawing.Point(1222, 106);
            this.baraja5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.baraja5.Name = "baraja5";
            this.baraja5.Size = new System.Drawing.Size(175, 240);
            this.baraja5.TabIndex = 6;
            this.baraja5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // Interfaz_juego
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::poker_cliente.Properties.Resources.fondo;
            this.ClientSize = new System.Drawing.Size(1409, 844);
            this.Controls.Add(this.baraja5);
            this.Controls.Add(this.baraja4);
            this.Controls.Add(this.Pasar_Btn);
            this.Controls.Add(this.baraja3);
            this.Controls.Add(this.baraja2);
            this.Controls.Add(this.baraja1);
            this.Controls.Add(this.Mano5);
            this.Controls.Add(this.Mano4);
            this.Controls.Add(this.Mano3);
            this.Controls.Add(this.Mano2);
            this.Controls.Add(this.Mano1);
            this.Controls.Add(this.panel_chat);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Interfaz_juego";
            this.Text = "Interfaz_juego";
            this.Load += new System.EventHandler(this.Interfaz_juego_Load);
            this.panel_chat.ResumeLayout(false);
            this.panel_chat.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_chat;
        private System.Windows.Forms.Label Chatlabel;
        private System.Windows.Forms.Button ChatEnviar;
        private System.Windows.Forms.TextBox ChatOutput;
        private System.Windows.Forms.TextBox ChatInput;
        private System.Windows.Forms.Panel Mano1;
        private System.Windows.Forms.Panel Mano2;
        private System.Windows.Forms.Panel Mano3;
        private System.Windows.Forms.Panel Mano4;
        private System.Windows.Forms.Panel Mano5;
        private System.Windows.Forms.Panel baraja1;
        private System.Windows.Forms.Panel baraja2;
        private System.Windows.Forms.Panel baraja3;
        private System.Windows.Forms.Button Pasar_Btn;
        private System.Windows.Forms.Panel baraja4;
        private System.Windows.Forms.Panel baraja5;
    }
}