﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace poker_cliente
{
    public partial class Interfaz_juego : Form
    {
        User user;
        Socket server;
        int ID_partida;
        public Panel[] ManoCartas = new Panel[5];
        public Panel[] Baraja = new Panel[3];
        public Interfaz_juego(User user, Socket server, int ID_partida)
        {
            InitializeComponent();
            this.user = user;
            this.server = server;
            this.ID_partida = ID_partida;
        }
        internal void RecibirChat(string mensaje)
        {
            string[] trozos = mensaje.Split('/');
            if (Convert.ToInt32(trozos[0]) == ID_partida)
            {
                ChatOutput.AppendText(String.Format("-> {0}: {1}", trozos[1], trozos[2])+Environment.NewLine);
                
            }
        }
      

        private void Interfaz_juego_Load(object sender, EventArgs e)
        {
            string mensaje = "7/" + this.ID_partida + "/" + this.user.Name;
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            
            server.Send(msg);
        }
        internal void RecibirMano(string mensaje)
        {
            ManoCartas[0] = Mano1;
            ManoCartas[1] = Mano2;
            ManoCartas[2] = Mano3;
            ManoCartas[3] = Mano4;
            ManoCartas[4] = Mano5;

            
            string[] trozos = mensaje.Split('/');
            Carta[] mano = new Carta[Convert.ToInt32(trozos[0])];
            for (int i = 1,j=0; i < 3*Convert.ToInt32(trozos[0]); i+=3,j++)
            {
                mano[j] = new Carta();
                mano[j].id = Convert.ToInt32(trozos[i]);
                mano[j].palo = trozos[i + 1];
                mano[j].numero = Convert.ToInt32(trozos[i + 2]);
                
                string resourceName = $"_{mano[j].numero}_{mano[j].palo}";
                if ((j)<5)
                {
                    ManoCartas[j].BackgroundImage = (Bitmap)Properties.Resources.ResourceManager.GetObject(resourceName);
                    ManoCartas[j].BackgroundImageLayout = ImageLayout.Stretch;
                }
                

            }
        }

        internal void DarBaraja(string mensaje) 
        {
            Baraja[0] = baraja1;
            Baraja[1] = baraja2;
            Baraja[2] = baraja3;

            string[] trozos = mensaje.Split('/');
            Carta[] mano = new Carta[Convert.ToInt32(trozos[0])];
            for (int i = 1; i < Convert.ToInt32(trozos[0]); i++)
            {
                mano[i - 1].id = Convert.ToInt32(trozos[i]);
                string resourceName = $"poker.Properties.Resources." + mano[i - 1].numero + "_" + Convert.ToInt32(mano[i - 2].palo) + ".png";
                ManoCartas[i - 1].BackgroundImage = (System.Drawing.Image)Properties.Resources.ResourceManager.GetObject(resourceName);

            }
        }
        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

      

        private void Pasar_Btn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Se ha acabado la partida");
            this.Close();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ChatEnviar_Click_1(object sender, EventArgs e)
        {
            string mensaje = "6/" + this.ID_partida + "/" + this.user.Name + "/" + ChatInput.Text;
            if (ChatInput.Text != "")
            {
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            ChatInput.Text = "";
        }
    }
}
