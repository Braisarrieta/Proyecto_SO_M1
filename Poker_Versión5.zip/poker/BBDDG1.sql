
USE Poker;
CREATE TABLE Usuarios(
					   ID_j INTEGER PRIMARY KEY NOT NULL,
					   Nombre TEXT NOT NULL,
					   Contraseña INTEGER NOT NULL
					   )ENGINE = InnoDB;

CREATE TABLE Partidas (
						ID_partida INT NOT NULL PRIMARY KEY AUTO_INCREMENT, 
						Num_jug INT, Duracion FLOAT, 
						Jugador1 INT NOT NULL, 
						Jugador2 INT NOT NULL, 
						Jugador3 INT NOT NULL, 
						Jugador4 INT NOT NULL, 
						FOREIGN KEY (Jugador1) REFERENCES Usuarios(ID_usuario),
						FOREIGN KEY (Jugador2) REFERENCES Usuarios(ID_usuario),
						FOREIGN KEY (Jugador3) REFERENCES Usuarios(ID_usuario),
						FOREIGN KEY (Jugador4) REFERENCES Usuarios(ID_usuario),
						Puntos_T1 INT, Puntos_T2 INT
						) ENGINE = InnoDB;



CREATE TABLE Ranking(
					 Jugador INTEGER NOT NULL,
					 Partida INTEGER NOT NULL,
					 ID_r INTEGER PRIMARY KEY NOT NULL,
					 FOREIGNER KEY (Usuarios) REFERENCES Jugador (Nombre),
					 )ENGINE = InnoDB;

CREATE TABLE Cartas (
    ID INT NOT NULL PRIMARY KEY, 
    Palo VARCHAR(30),
    Numero INT
)ENGINE = InnoDB;

INSERT INTO Usuarios(Nombre, Correo, Password) 
VALUES (1,'a','a'),(2,'b','b'),(3,'c','c'),(4,'d','d'),(5,'s','s');

INSERT INTO Cartas(ID, Palo, Numero) 
VALUES (1,'corazones',1),(2,'corazones',2),(3,'corazones',3),(4,'corazones',4),(5,'corazones',5),(6,'corazones',6),(7,'corazones',7),(8,'corazones',8),(9,'corazones',9),(10,'corazones',10),(11,'corazones',11),(12,'corazones',12),(13,'corazones',13),
(1,'picas',1),(2,'picas',2),(3,'picas',3),(4,'picas',4),(5,'picas',5),(6,'picas',6),(7,'picas',7),(8,'picas',8),(9,'picas',9),(10,'picas',10),(11,'picas',11),(12,'picas',12),(13,'picas',13),
(1,'treboles',1),(2,'treboles',2),(3,'treboles',3),(4,'treboles',4),(5,'treboles',5),(6,'treboles',6),(7,'treboles',7),(8,'treboles',8),(9,'pitrebolescas',9),(10,'treboles',10),(11,'treboles',11),(12,'treboles',12),(13,'treboles',13),
(1,'diamantes',1),(2,'diamantes',2),(3,'diamantes',3),(4,'diamantes',4),(5,'diamantes',5),(6,'diamantes',6),(7,'diamantes',7),(8,'diamantes',8),(9,'diamantes',9),(10,'diamantes',10),(11,'diamantes',11),(12,'diamantes',12),(13,'diamantes',13)
