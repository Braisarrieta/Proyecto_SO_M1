﻿namespace poker_cliente
{
    partial class Principal_Logged
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal_Logged));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Conectados = new System.Windows.Forms.ToolStrip();
            this.dataGridConectados = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ModeComboBox = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.Jugador1ComboBox = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStrip4 = new System.Windows.Forms.ToolStrip();
            this.toolStrip5 = new System.Windows.Forms.ToolStrip();
            this.Jugador2ComboBox = new System.Windows.Forms.ToolStripSplitButton();
            this.Jugador3ComboBox = new System.Windows.Forms.ToolStripSplitButton();
            this.EnviarPartida = new System.Windows.Forms.Button();
            this.logOut = new System.Windows.Forms.ToolStripSplitButton();
            this.panelConectados = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStrip1.SuspendLayout();
            this.Conectados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridConectados)).BeginInit();
            this.panel1.SuspendLayout();
            this.ModeComboBox.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            this.toolStrip4.SuspendLayout();
            this.toolStrip5.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.logOut});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1433, 38);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Conectados
            // 
            this.Conectados.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.Conectados.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.panelConectados});
            this.Conectados.Location = new System.Drawing.Point(0, 38);
            this.Conectados.Name = "Conectados";
            this.Conectados.Size = new System.Drawing.Size(1433, 38);
            this.Conectados.TabIndex = 1;
            this.Conectados.Text = "toolStrip2";
            this.Conectados.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip2_ItemClicked);
            // 
            // dataGridConectados
            // 
            this.dataGridConectados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridConectados.Location = new System.Drawing.Point(84, 514);
            this.dataGridConectados.Name = "dataGridConectados";
            this.dataGridConectados.RowHeadersWidth = 62;
            this.dataGridConectados.RowTemplate.Height = 28;
            this.dataGridConectados.Size = new System.Drawing.Size(298, 290);
            this.dataGridConectados.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.EnviarPartida);
            this.panel1.Controls.Add(this.toolStrip5);
            this.panel1.Controls.Add(this.toolStrip4);
            this.panel1.Controls.Add(this.toolStrip3);
            this.panel1.Controls.Add(this.ModeComboBox);
            this.panel1.Location = new System.Drawing.Point(678, 178);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(721, 375);
            this.panel1.TabIndex = 3;
            // 
            // ModeComboBox
            // 
            this.ModeComboBox.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.ModeComboBox.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1});
            this.ModeComboBox.Location = new System.Drawing.Point(0, 0);
            this.ModeComboBox.Name = "ModeComboBox";
            this.ModeComboBox.Size = new System.Drawing.Size(721, 34);
            this.ModeComboBox.TabIndex = 2;
            this.ModeComboBox.Text = "¿Cuántos jugadores quieres invitar?";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(313, 29);
            this.toolStripButton1.Text = "¿Cuántos jugadores quieres invitar?";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(270, 34);
            this.toolStripMenuItem2.Text = "2";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(270, 34);
            this.toolStripMenuItem3.Text = "4";
            // 
            // toolStrip3
            // 
            this.toolStrip3.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Jugador1ComboBox});
            this.toolStrip3.Location = new System.Drawing.Point(0, 34);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(721, 34);
            this.toolStrip3.TabIndex = 3;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // Jugador1ComboBox
            // 
            this.Jugador1ComboBox.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Jugador1ComboBox.Image = ((System.Drawing.Image)(resources.GetObject("Jugador1ComboBox.Image")));
            this.Jugador1ComboBox.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Jugador1ComboBox.Name = "Jugador1ComboBox";
            this.Jugador1ComboBox.Size = new System.Drawing.Size(108, 29);
            this.Jugador1ComboBox.Text = "Invitado1";
            // 
            // toolStrip4
            // 
            this.toolStrip4.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Jugador2ComboBox});
            this.toolStrip4.Location = new System.Drawing.Point(0, 68);
            this.toolStrip4.Name = "toolStrip4";
            this.toolStrip4.Size = new System.Drawing.Size(721, 34);
            this.toolStrip4.TabIndex = 4;
            this.toolStrip4.Text = "toolStrip4";
            // 
            // toolStrip5
            // 
            this.toolStrip5.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Jugador3ComboBox});
            this.toolStrip5.Location = new System.Drawing.Point(0, 102);
            this.toolStrip5.Name = "toolStrip5";
            this.toolStrip5.Size = new System.Drawing.Size(721, 34);
            this.toolStrip5.TabIndex = 5;
            this.toolStrip5.Text = "toolStrip5";
            // 
            // Jugador2ComboBox
            // 
            this.Jugador2ComboBox.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Jugador2ComboBox.Image = ((System.Drawing.Image)(resources.GetObject("Jugador2ComboBox.Image")));
            this.Jugador2ComboBox.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Jugador2ComboBox.Name = "Jugador2ComboBox";
            this.Jugador2ComboBox.Size = new System.Drawing.Size(108, 29);
            this.Jugador2ComboBox.Text = "Inviatdo2";
            // 
            // Jugador3ComboBox
            // 
            this.Jugador3ComboBox.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Jugador3ComboBox.Image = ((System.Drawing.Image)(resources.GetObject("Jugador3ComboBox.Image")));
            this.Jugador3ComboBox.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Jugador3ComboBox.Name = "Jugador3ComboBox";
            this.Jugador3ComboBox.Size = new System.Drawing.Size(108, 29);
            this.Jugador3ComboBox.Text = "Invitado3";
            // 
            // EnviarPartida
            // 
            this.EnviarPartida.Font = new System.Drawing.Font("Arial", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnviarPartida.Location = new System.Drawing.Point(226, 203);
            this.EnviarPartida.Name = "EnviarPartida";
            this.EnviarPartida.Size = new System.Drawing.Size(242, 81);
            this.EnviarPartida.TabIndex = 6;
            this.EnviarPartida.Text = "Invitar";
            this.EnviarPartida.UseVisualStyleBackColor = true;
            // 
            // logOut
            // 
            this.logOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.logOut.Image = ((System.Drawing.Image)(resources.GetObject("logOut.Image")));
            this.logOut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.logOut.Name = "logOut";
            this.logOut.Size = new System.Drawing.Size(98, 33);
            this.logOut.Text = "Log Out";
            this.logOut.ToolTipText = "Log out";
            this.logOut.Click += new System.EventHandler(this.logOut_Click);
            // 
            // panelConectados
            // 
            this.panelConectados.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.panelConectados.Image = ((System.Drawing.Image)(resources.GetObject("panelConectados.Image")));
            this.panelConectados.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.panelConectados.Name = "panelConectados";
            this.panelConectados.Size = new System.Drawing.Size(127, 33);
            this.panelConectados.Text = "Conectados";
            this.panelConectados.Click += new System.EventHandler(this.conectados_Click);
            // 
            // Principal_Logged
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1433, 894);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridConectados);
            this.Controls.Add(this.Conectados);
            this.Controls.Add(this.toolStrip1);
            this.Name = "Principal_Logged";
            this.Text = "Principal_Logged";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.Conectados.ResumeLayout(false);
            this.Conectados.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridConectados)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ModeComboBox.ResumeLayout(false);
            this.ModeComboBox.PerformLayout();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.toolStrip4.ResumeLayout(false);
            this.toolStrip4.PerformLayout();
            this.toolStrip5.ResumeLayout(false);
            this.toolStrip5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStrip Conectados;
        private System.Windows.Forms.DataGridView dataGridConectados;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStrip ModeComboBox;
        private System.Windows.Forms.ToolStripSplitButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.Button EnviarPartida;
        private System.Windows.Forms.ToolStrip toolStrip5;
        private System.Windows.Forms.ToolStripSplitButton Jugador3ComboBox;
        private System.Windows.Forms.ToolStrip toolStrip4;
        private System.Windows.Forms.ToolStripSplitButton Jugador2ComboBox;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripSplitButton Jugador1ComboBox;
        private System.Windows.Forms.ToolStripSplitButton logOut;
        private System.Windows.Forms.ToolStripSplitButton panelConectados;
    }
}